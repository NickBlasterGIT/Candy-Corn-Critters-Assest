Personal Use contains the demo font, use the higher license to be able to use the full version

Full version availiable:
https://jetsmax.com/taki-typeface/

Donate:
https://paypal.me/KhairilAnwar