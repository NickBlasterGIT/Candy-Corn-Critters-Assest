BoB Font is Free!

https://www.behance.net/silencemunky