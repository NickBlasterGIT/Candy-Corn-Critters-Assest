Recently I moved to Sofia, Bulgaria. Firstly I was so impressed and surprised 
how many graffiti is everywhere in the city. There are many talented graffiti artists here, 
as well as just tagging.

So I was inspired by the place and decided to try my best to create bubble graffiti style font. It is completely free for personal and commercial use. Please, enjoy, create and play!

Like, share and follow me on Instagram 
https://www.instagram.com/volkova.graphicdesigner/

I am available for projects. 
Please, contact me in any convenient way:

liubov.vik.volkova@gmail.com or facebook 
https://www.facebook.com/liubov.volkova.9/